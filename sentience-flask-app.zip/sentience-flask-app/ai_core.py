import openai
import os

# Set up OpenAI API key
openai.api_key = os.getenv("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")

def generate_prophet_response(user_input):
    """Generate a mystical, poetic response from the AI."""
    prompt = f"Respond in a cryptic, poetic manner to the following query: {user_input}"

    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100,
        temperature=0.9
    )

    return response.choices[0].text.strip()
