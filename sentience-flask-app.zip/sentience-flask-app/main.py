from flask import Flask, request, jsonify
from ai_core import generate_prophet_response
from flask_cors import CORS
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable cross-origin resource sharing for API requests

@app.route("/ask", methods=["POST"])
def ask():
    user_input = request.json.get("input")
    if not user_input:
        return jsonify({"error": "No input provided"}), 400

    # Generate response using AI model
    response = generate_prophet_response(user_input)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
